import React from 'react';
import { Star } from 'lucide-react';

interface ProductCardProps {
  title: string;
  price: number;
  originalPrice: number;
  rating: number;
  image: string;
}

export default function ProductCard({ title, price, originalPrice, rating, image }: ProductCardProps) {
  const discount = Math.round(((originalPrice - price) / originalPrice) * 100);

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
      <div className="relative aspect-square overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-md text-sm font-semibold">
          {discount}% OFF
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-gray-800 font-semibold text-lg mb-2 line-clamp-2">{title}</h3>
        <div className="flex items-center mb-2">
          <div className="flex items-center bg-green-500 text-white px-2 py-1 rounded-md">
            <span className="font-bold mr-1">{rating}</span>
            <Star className="h-4 w-4 fill-current" />
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-xl font-bold text-gray-900">₹{price}</span>
          <span className="text-sm text-gray-500 line-through">₹{originalPrice}</span>
        </div>
      </div>
    </div>
  );
}