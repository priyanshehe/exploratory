import React, { useState } from 'react';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import SignInModal from './components/SignInModal';

const PRODUCTS = [
  {
    id: 1,
    title: "Men's Premium Cotton T-Shirt",
    price: 499,
    originalPrice: 999,
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&auto=format"
  },
  {
    id: 2,
    title: "Women's Designer Handbag",
    price: 1499,
    originalPrice: 2999,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=500&auto=format"
  },
  {
    id: 3,
    title: "Premium Wireless Headphones",
    price: 2999,
    originalPrice: 5999,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format"
  },
  {
    id: 4,
    title: "Smart Fitness Watch",
    price: 3999,
    originalPrice: 7999,
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format"
  },
  {
    id: 5,
    title: "Professional DSLR Camera",
    price: 54999,
    originalPrice: 69999,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500&auto=format"
  },
  {
    id: 6,
    title: "Luxury Sunglasses",
    price: 2499,
    originalPrice: 4999,
    rating: 4.4,
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&auto=format"
  },
  {
    id: 7,
    title: "Designer Running Shoes",
    price: 3999,
    originalPrice: 7999,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format"
  },
  {
    id: 8,
    title: "Premium Leather Wallet",
    price: 999,
    originalPrice: 1999,
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=500&auto=format"
  }
];

function App() {
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-rose-500 to-pink-500 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Welcome to ShopHub</h1>
            <p className="text-xl mb-8">Discover amazing deals on trending products</p>
            <button 
              onClick={() => setIsSignInOpen(true)}
              className="bg-white text-rose-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300"
            >
              Sign In to Get Started
            </button>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {PRODUCTS.map((product) => (
            <ProductCard
              key={product.id}
              title={product.title}
              price={product.price}
              originalPrice={product.originalPrice}
              rating={product.rating}
              image={product.image}
            />
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">About ShopHub</h3>
              <p className="text-gray-400">Your one-stop destination for all your shopping needs. We offer the best prices and deals on premium products.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><button className="hover:text-white">About Us</button></li>
                <li><button className="hover:text-white">Contact</button></li>
                <li><button className="hover:text-white">Shipping Policy</button></li>
                <li><button className="hover:text-white">Return Policy</button></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
              <ul className="space-y-2 text-gray-400">
                <li><button className="hover:text-white">Facebook</button></li>
                <li><button className="hover:text-white">Twitter</button></li>
                <li><button className="hover:text-white">Instagram</button></li>
                <li><button className="hover:text-white">LinkedIn</button></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 ShopHub. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <SignInModal isOpen={isSignInOpen} onClose={() => setIsSignInOpen(false)} />
    </div>
  );
}

export default App;